#pragma once
#include "Ship.h"

// A cruiser is basically the same thing as a destroyer, except for the health.
// If you change something here, change it in the corresponding class!

class Destroyer : public Ship {
public:
	Destroyer() { type = DESTROYER; set_remaining_health(get_max_health()); set_last_turn_fired(-1); }
	int get_max_health() { return 2; }
	bool can_attack(int turn) { return !get_wreck(); }

	Grid* do_attack(Ship* attacked_ship, Grid* attacked_grid, int attacked_location) {
		return attacked_ship->defend(attacked_grid, attacked_location);
	}
};
